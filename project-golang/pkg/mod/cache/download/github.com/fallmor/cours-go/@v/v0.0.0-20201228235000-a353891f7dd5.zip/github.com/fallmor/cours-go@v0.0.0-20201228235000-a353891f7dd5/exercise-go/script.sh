#!/bin/bash
test=(0 2 3 4 5)

for i in "${test[@]}"; do
        mkdir exercise-$i

done